extern
void hardware(const int write_to_file, FILE *global_ofile);
